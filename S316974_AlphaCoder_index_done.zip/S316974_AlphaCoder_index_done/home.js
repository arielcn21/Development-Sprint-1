function openNav() {
  document.getElementById("mysidenav").style.width = "140px";
  }
function closeNav() {
  document.getElementById("mysidenav").style.width = "0";
  }
